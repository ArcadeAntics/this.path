pseudoglobalenv <- function (...)
.Defunct("essentials::pseudoglobalenv")
