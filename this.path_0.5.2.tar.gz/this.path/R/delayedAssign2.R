delayedAssign2 <- function (...)
.Defunct("essentials:::delayedAssign2")
