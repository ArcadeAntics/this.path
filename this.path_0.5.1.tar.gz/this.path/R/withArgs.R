Args <- function (...)
.Defunct("essentials::Args")


withArgs <- function (...)
.Defunct("essentials::withArgs")
