asArgs <- function (...)
.Defunct("essentials:::asArgs")


as.comment <- function (...)
.Defunct("essentials:::as.comment")


splitter.inator <- function (...)
.Defunct("essentials:::splitter.inator")





format4scan <- function (...)
.Defunct("essentials::format4scan")


format4parse <- function (...)
.Defunct("essentials:::format4parse")





scan2 <- function (...)
.Defunct("essentials::scan2")


regexQuote <- function (...)
.Defunct("essentials::regexQuote")


has.ext <- function (...)
.Defunct("essentials::has.ext")





setReadWriteArgsMethod <- function (...)
.Defunct("essentials::setReadWriteArgsMethod")





selectReadWriteArgsMethod <- function (...)
.Defunct("essentials::selectReadWriteArgsMethod")





writeArgs <- function (...)
.Defunct("essentials::writeArgs")


readArgs <- function (...)
.Defunct("essentials::readArgs")
