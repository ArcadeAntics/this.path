isName <- function (...)
.Defunct("essentials:::isName")


isNameOrFlag <- function (...)
.Defunct("essentials:::isNameOrFlag")


isFlag <- function (...)
.Defunct("essentials:::isFlag")


isShortFlag <- function (...)
.Defunct("essentials:::isShortFlag")


isLongFlag <- function (...)
.Defunct("essentials:::isLongFlag")


getTag <- function (...)
.Defunct("essentials:::getTag")


hasValue <- function (...)
.Defunct("essentials:::hasValue")


getValue <- function (...)
.Defunct("essentials:::getValue")





format.help <- function (...)
.Defunct("essentials:::format.help")


match.action <- function (...)
.Defunct("essentials:::match.action")


parse.nargs <- function (...)
.Defunct("essentials:::parse.nargs")


nargs.description <- function (...)
.Defunct("essentials:::nargs.description")


print.formalCommandArg <- function (...)
.Defunct("essentials:::print.formalCommandArg")
