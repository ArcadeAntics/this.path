commandQuote <- function (...)
.Defunct("essentials::shEncode")


shEncode <- commandQuote
