path.contract <- function (...)
.Defunct("essentials::path.contract")
