if (FALSE) {
    (function() {
        pkg <- "this.path"

        owd <- getwd()
        if (!is.null(owd))
            on.exit(setwd(owd))
        setwd("~")
        cat("\n")

        command <- sprintf("R CMD INSTALL %s --with-keep.source", pkg)
        cat(this.path:::format.command(command), "\n", sep = "")
        cat("\n")
        system(command)
        cat("\n")

        command <- sprintf("R CMD build %s", pkg)
        cat(this.path:::format.command(command), "\n", sep = "")
        cat("\n")
        system(command)

        command <- sprintf("R CMD check %s_%s.tar.gz --as-cran",
            pkg, utils::packageVersion(pkg))
        cat(this.path:::format.command(command), "\n", sep = "")
        cat("\n")
        invisible(system(command))
    })()
}
