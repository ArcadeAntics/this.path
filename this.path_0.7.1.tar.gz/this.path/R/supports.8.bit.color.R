supports.8.bit.color <- function (...)
.Defunct("essentials:::supports.8.bit.color")
