file.open <- function (...)
.Defunct("essentials::file.open")
