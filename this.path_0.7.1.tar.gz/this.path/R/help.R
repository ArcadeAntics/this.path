pattern <- function (...)
.Defunct("essentials:::pattern")


replacement <- function (...)
.Defunct("essentials:::replacement")


cond <- function (...)
.Defunct("essentials:::cond")


arg <- function (...)
.Defunct("essentials:::arg")


help.sub <- function (...)
.Defunct("essentials:::help.sub")
