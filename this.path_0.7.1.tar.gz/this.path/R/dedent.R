dedent <- function (...)
.Defunct("essentials:::dedent")
