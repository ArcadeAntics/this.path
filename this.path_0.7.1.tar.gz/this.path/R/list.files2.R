list.files2 <- function (...)
.Defunct("essentials::list.files2")


dir2 <- list.files2
