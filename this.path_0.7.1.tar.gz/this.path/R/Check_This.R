switch2 <- function (...)
.Defunct("essentials:::switch2")


Check_This <- function (...)
.Defunct("essentials:::Check_This")
