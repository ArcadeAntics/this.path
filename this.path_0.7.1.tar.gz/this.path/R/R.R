.system <- function (...)
.Defunct("essentials:::.system")





python <- function (...)
.Defunct("essentials::python")





.R <- function (...)
.Defunct("essentials:::.R")


R <- function (...)
.Defunct("essentials::R")


Rcmd <- function (...)
.Defunct("essentials::Rcmd")


Rgui <- function (...)
.Defunct("essentials:::Rgui")


Rscript <- function (...)
.Defunct("essentials::Rscript")


Rterm <- function (...)
.Defunct("essentials::Rterm")





.Rscript <- function (options = NULL, ...)
{
    command <- file.path(R.home("bin"), "Rscript")
    args <- c(command, options)
    command <- paste(shQuote(args), collapse = " ")
    cat(command, "\n", sep = "")
    invisible(system(command = command, ...))
}
