commandPrompt <- function (...)
.Defunct("essentials::shPrompt")
