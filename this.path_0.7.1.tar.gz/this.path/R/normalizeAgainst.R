normalizeAgainst <- function (...)
.Defunct("essentials:::normalizeAgainst")


.normalizePath <- function (...)
.Defunct("essentials:::.normalizePath")
