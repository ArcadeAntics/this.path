GetConnection <- function (file)
.External2(C_getconnection, file)


GetUnderlyingConnection <- function (file)
.External2(C_getunderlyingconnection, file)
